#include "header.h"
string LoginRW::getClientID() {
	return this->clientID;
}
void LoginRW::setClientID(string id) {
	this->clientID = id;
}
string LoginRW::getPassword() {
	return this->password;
}
void LoginRW::setPassword(string password) {
	this->password = password;
}