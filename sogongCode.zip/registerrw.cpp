#include "header.h"
string RegisterRW::getName() {
	return this->name;
}
void RegisterRW::setName(string name) {
	this->name = name;
}
string RegisterRW::getCompany() {
	return this->company;
}
void RegisterRW::setCompany(string company) {
	this->company = company;
}
int RegisterRW::getPrice() {
	return this->price;
}
void RegisterRW::setPrice(int price) {
	this->price = price;
}
int RegisterRW::getQuantity() {
	return this->quantity;
}
void RegisterRW::setQuantity(int quantity) {
	this->quantity = quantity;
}