#include "header.h"
string SignUpRW::getName() {
	return this->name;
}
void SignUpRW::setName(string name) {
	this->name = name;
}
string SignUpRW::getClientID() {
	return this->clientID;
}
void SignUpRW::setClientID(string id) {
	this->clientID = id;
}
string SignUpRW::getPassword() {
	return this->password;
}
void SignUpRW::setPassword(string password) {
	this->password = password;
}
int SignUpRW::getResidentRegistrationNumber() {
	return this->residentRegistrationNumber;
}
void SignUpRW::setResidentRegistrationNumber(int num) {
	this->residentRegistrationNumber = num;
}
