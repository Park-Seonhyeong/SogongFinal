#include "header.h"
string Product::getName() { 
	return this->name;
}
void Product::setName(string name) {
	this->name = name;
}
string Product::getCompany() { 
	return this->company;
}
void Product::setCompany(string company) { 
	this->company = company; 
}
int Product::getPrice() { 
	return this->price;
}
void Product::setPrice(int price) { 
	this->price = price;
}
int Product::getQuantity() { 
	return this->quantity; 
}
void Product::setQuantity(int quantity) { 
	this->quantity = quantity; 
}
string Product::getSellerID() {
	return this->sellerID;
}
void Product::setSellerID(string sellerID) {
	this->sellerID = sellerID;
}