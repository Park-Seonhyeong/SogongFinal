#include "header.h"
Purchase::Purchase() {
	PurchaseRW purchaserw;
	cout << "Purchase::Purchas����" << endl;
	purchaserw.read(this);
	cout << "Purchase::read����" << endl;
	purchaserw.write(this);
}
string Purchase::purchaseProduct(ProductList* productList, ClientList* clientList, string loginuser, string productname) {
	Product* product = productList->getProduct(productname);
	cout << '1' << product->getName() << endl;
	Client* client = clientList->getClient(loginuser);
	cout << '2' << client->getClientID() << endl;
	string sellerID = product->getSellerID();
	int quantity = product->getQuantity();
	product->setQuantity(quantity - 1);
	return sellerID;
}//���� �����ϸ� �Ǹ��� �̸� �ʿ�. string ���·� sellerID return���ֱ�.