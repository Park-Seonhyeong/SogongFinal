#include "header.h"
string Login::getClientID() {
	return this->clientID;
}
void Login::setClientID(string id) {
	this->clientID = id;
}
string Login::getPassword() {
	return this->password;
}
void Login::setPassword(string password) {
	this->password = password;
}

Login::Login() {
	LoginRW loginrw;
	loginrw.read(this);
	loginrw.write(this);
}

string Login::loginClient(ClientList* client, string clientID, string password) {
	cout << "Login loginclient����" << endl;
	string user = client->loginClient(clientID, password);
	return user;
}