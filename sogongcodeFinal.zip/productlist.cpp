#include "header.h"
int ProductList::getTotalNum() {
	return this->totalnum; 
}
void ProductList::setTotalNum(int num) {
	this->totalnum = num; 
}
void ProductList::createProduct(Product *product) {
	int productNumber = this->getTotalNum();
	productList[productNumber] = product;
	this->setTotalNum(productNumber + 1);
}
Product* ProductList::getProduct(string name) {
	int num = this->getTotalNum();
	for (int i = 0; i < num; i++) {
		if (productList[i]->getName() == name) {
			return productList[i];
		}
	}
}
ProductDetail* ProductList::makeproduct(string name) {
	ProductDetail* productdetail = new ProductDetail;
	Product* product = this->getProduct(name);
	cout << product->getName()<<endl;
	cout << "productdetail" << endl;
	cout << product->getSellerID();
	string seller = product->getSellerID();
	string productname = product->getName();
	string company = product->getCompany();
	int price = product->getPrice();
	int quantity = product->getQuantity();//������� ���� ����
	productdetail->setSellerID(seller);
	productdetail->setName(productname);
	productdetail->setCompany(company);
	productdetail->setPrice(price);
	productdetail->setQuantity(quantity);//ProductDetail* class�� �ϳ� return ����. ���⼭ ���� �����ٰ� output�� write�� ����.
	return productdetail;
}