#include "header.h"
#include <iostream>
#include <fstream>
#include <string>
#define INPUT_FILE_NAME "input.txt"
#define OUTPUT_FILE_NAME "output.txt"

using namespace std;

ifstream in_file;
ofstream out_file;
string loginUser = "";//���� �α����� user. Not user�̸� �α��� �ȵȻ�����.
string searchproduct = "";//���� �˻����� ��ǰ�̸�.
string sellerName = "";//�Ǹ��� �̸�.SellerID�� �򰥸� �� �־ sellerName
ClientList client;
ProductList productlist;
void SignUpRW::read(SignUp* signup) {
    string name;
    int residentRegistrationNumber;
    string clientID;
    string password;
    in_file >> name >> residentRegistrationNumber >> clientID >> password;
    this->setName(name);
    this->setResidentRegistrationNumber(residentRegistrationNumber);
    this->setClientID(clientID);
    this->setPassword(password);
    signup->addNewClient(&client, name, residentRegistrationNumber, clientID, password);
}
void SignUpRW::write(SignUp* signup) {
    out_file << "1.1 ȸ������" << endl;
    out_file << ">" << " ";
    out_file << this->getName() << " " << this->getResidentRegistrationNumber() << " " << this->getClientID() << " " << this->getPassword()<<endl;
    out_file << endl;
}
void LoginRW::read(Login* login) {
    string clientID;
    string password;
    in_file >> clientID >> password;
    this->setClientID(clientID);
    this->setPassword(password);
    loginUser=login->loginClient(&client,clientID,password);
    
}
void LoginRW::write(Login* login) {
    out_file << "2.1 �α���" << endl;
    out_file << ">" << " ";
    if (loginUser == "Not User") {
        out_file << endl;
    }
    else {
        out_file << this->getClientID() << " " << this->getPassword()<<endl;
    }
}
void SearchRW::read(Search* search) {
    string name;
    in_file >> name;
    searchproduct = name;
    search->getProduct(&productlist, name);
}
void SearchRW::write(ProductDetail* productdetail) {
    out_file << "4.1 ��ǰ ���� �˻�" << endl;
    out_file << ">" << " ";
    out_file << productdetail->getSellerID() <<" "<< productdetail->getName() << " " << productdetail->getCompany() << " " << productdetail->getPrice() << " " << productdetail->getQuantity() << " " <<endl;
}
void RegisterRW::read(RegisterSaleProduct* registersaleproduct) {
    string name;
    string company;
    int price;
    int quantity;
    in_file >> name >> company >> price >> quantity;
    this->setName(name);
    this->setCompany(company);
    this->setPrice(price);
    this->setQuantity(quantity);
    registersaleproduct->registerSaleProduct(&client,& productlist, loginUser, name, company,  price, quantity);

}
void RegisterRW::write(RegisterSaleProduct* registersaleproduct) {
    out_file << "3.1 �Ǹ� �Ƿ� ���" << endl;
    out_file << ">" << " ";
    out_file << this->getName() << " " << this->getCompany() << " " << this->getPrice() << " " << this->getQuantity() << endl;
    
}
void PurchaseRW::read(Purchase* purchase) {
    cout << "read������ ����" << endl;
    cout << "loginuser:" << loginUser << endl;
    cout<<"searchProduct:"<<searchproduct << endl;
    string sellerID = purchase->purchaseProduct(&productlist, &client, loginUser, searchproduct);
    cout << "purchaseRW�� read ����"<<sellerID << endl;
    cout << sellerID << endl;
    this->setSellerID(sellerID);
    this->setName(searchproduct);
}
void PurchaseRW::write(Purchase* purchase) {
    out_file << "4.2 ��ǰ ����" << endl;
    out_file << ">" << " ";
    out_file << this->getSellerID() << " " << this->getName()<< endl;

}
void join() {
    SignUp signup;
}//communication diagram �ݿ� �Ϸ�
void login() {
    Login login;
}//communication diagram �ݿ� �Ϸ�
void registersaleproduct() {
    RegisterSaleProduct registersaleproduct;
}//communication diagram �ݿ� �Ϸ�
void search() {
    Search search;
}//communication diagram �ݿ� �Ϸ�
void purchase() {
    Purchase purchase;
}//communication diagram �ݿ� �Ϸ�
void doTask()
{
    // �޴� �Ľ��� ���� level ������ ���� ����
    int menu_level_1 = 0, menu_level_2 = 0;
    int is_program_exit = 0;

    while (!is_program_exit)
    {
        // �Է����Ͽ��� �޴� ���� 2���� �б�
        in_file >> menu_level_1 >> menu_level_2;
        // �޴� ���� �� �ش� ���� ����
        switch (menu_level_1) {
        case 1: {
            switch (menu_level_2) {
            case 1: { // 1.1. ȸ�� ����
                join();
            }
            case 2: { // 1.2. ȸ�� Ż��xxxx


                break;
            }
            }
            break;
        }

        case 2: {
            switch (menu_level_2) { // 2.1. �α���
            case 1: {
                login();
                break;
            }
            case 2: { // 2.2. �α׾ƿ�
                out_file << "2.2 �α׾ƿ�" << endl;
                out_file << ">" << " ";
                out_file << loginUser << endl;
                loginUser = "Not User";
                break;
            }
            }
            break;
        }

        case 3: {
            switch (menu_level_2) {
            case 1: { // 3.1. �Ǹ� �Ƿ� ���
                registersaleproduct();
                break;
            }
            case 2: { // 3.2. ��� ��ǰ ��ȸ xx


                break;
            }
            case 3: { // 3.3. �Ǹ� �Ϸ� ��ǰ ��ȸ xx


                break;
            }
            }
            break;
        }
        case 4: {
            switch (menu_level_2) {
            case 1: { // 4.1. ��ǰ ���� �˻�
                search();
                break;
            }
            case 2: { // 4.2. ��ǰ ����
                purchase();
                break;
            }
            case 3: { // 4.3. ��ǰ ���� ���� ��ȸxx


                break;
            }
            case 4: { //4.4. ��ǰ ���Ÿ����� �� xx


                break;
            }
            }
            break;
        }
        case 5: { // 5.1. �Ǹ� ��ǰ ��� xx

            break;
        }
        case 6: { // 6.1. ����
            is_program_exit = 1;
            break;
        }
        }
    }
}

int main()
{
    // ���� ������� ���� �ʱ�ȭ
    in_file.open(INPUT_FILE_NAME);
    out_file.open(OUTPUT_FILE_NAME);

    doTask();

    return 0;
}