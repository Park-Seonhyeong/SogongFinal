#include "header.h"
string Client::getName() { 
    return this->name;
}
void Client::setName(string name) {
    this->name = name;
}
string Client::getClientID() { 
    return this->clientID;
}
void Client::setClientID(string id) { 
    this->clientID = id; 
}
string Client::getPassword() { 
    return this->password;
}
void Client::setPassword(string password) { 
    this->password = password;
}
int Client::getResidentRegistrationNumber() {
    return this->residentRegistrationNumber;
}
void Client::setResidentRegistrationNumber(int num) {
    this->residentRegistrationNumber = num;
}
SaleList Client::getSaleList() {
    return this->salelist;
}
void Client::addSaleProduct(Product* product) {
    SaleList salelist = this->getSaleList();
    salelist.createSaleProduct(product);
}//�Ǹ��ϴ� ��ǰ ������ �ֱ� ���� addSaleProduct�Լ� ����. 