#include "header.h"
string ProductDetail::getSellerID() {
	return this->sellerID; 
}
void ProductDetail::setSellerID(string sellerID) {
	this->sellerID = sellerID;
}
string ProductDetail::getName() { 
	return this->name;
}
void ProductDetail::setName(string name) { 
	this->name = name;
}
string ProductDetail::getCompany() { 
	return this->company; 
}
void ProductDetail::setCompany(string name) {
	this->name = name;
}
int ProductDetail::getPrice() {
	return this->price;
}
void ProductDetail::setPrice(int price) {
	this->price = price;
}
int ProductDetail::getQuantity() { 
	return this->quantity;
}
void ProductDetail::setQuantity(int quantity) { 
	this->quantity = quantity;
}