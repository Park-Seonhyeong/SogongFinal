#include "header.h"
string PurchaseRW::getSellerID() {
	return this->sellerID;
}
void PurchaseRW::setSellerID(string sellerID) {
	this->sellerID = sellerID;
}
string PurchaseRW::getName() {
	return this->name;
}
void PurchaseRW::setName(string name) {
	this->name = name;
}