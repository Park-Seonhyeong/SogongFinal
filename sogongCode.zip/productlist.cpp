#include "header.h"
int ProductList::getTotalNum() {
	return this->totalnum;
}
void ProductList::setTotalNum(int num) {
	this->totalnum = num;
}
void ProductList::createProduct(Product* product) {
	int productNumber = this->getTotalNum();
	productList[productNumber] = product;
	this->setTotalNum(productNumber + 1);
}
Product* ProductList::getProduct(string name) {
	int num = this->getTotalNum();
	for (int i = 0; i < num; i++) {
		if (productList[i]->getName() == name) {
			return productList[i];
		}
	}
}