#include "header.h"
string SignUp::getName() {
    return this->name;
}
void SignUp::setName(string name) {
    this->name = name;
}
string SignUp::getClientID() {
    return this->clientID;
}
void SignUp::setClientID(string id) {
    this->clientID = id;
}
string SignUp::getPassword() {
    return this->password;
}
void SignUp::setPassword(string password) {
    this->password = password;
}
SignUp::SignUp() {
    SignUpRW signuprw;
    signuprw.read(this);
    signuprw.write(this);
}
void SignUp::addNewClient(ClientList* client, string name, int residentRegistrationNumber, string clientID, string password) {
    cout << "signup addnewclient ����" << endl;
    client->createClient(name, residentRegistrationNumber, clientID, password);
};//clientLIst�� ȸ�������� ���� push�ذ��鼭 user�� �����������.